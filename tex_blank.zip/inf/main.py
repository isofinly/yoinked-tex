from task4 import task4
from task5 import task5


def main():
    task4()
    task5()


if __name__ == '__main__':
    main()
